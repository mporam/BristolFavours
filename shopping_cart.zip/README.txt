Instructions for setting up the Ecommerce Plus templates are available on-line at . . .

http://www.ecommercetemplates.com/phphelp/ecommplus/instructions.asp

You will also find items of interest at . . .

http://www.ecommercetemplates.com/phphelp/ecommplus/help.asp
http://www.ecommercetemplates.com/phphelp/ecommplus/faq.asp

Please also review our downloadable help documents from . . . 
http://www.ecommercetemplates.com/free_downloads.asp

We also have a support form at . . . 
http://www.ecommercetemplates.com/support/

If you have purchased a product with a dynamic DHTML menu, you must set your 
database connection as specified in the instructions before you can view any 
pages in your browser.
