<?php
session_cache_limiter('none');
session_start();
ob_start(); ?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php
include 'vsadmin/db_conn_open.php';
include 'vsadmin/inc/languagefile.php';
include 'vsadmin/includes.php';
include 'vsadmin/inc/incfunctions.php'; ?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title><?php print $xxEmFrnd?></title>
<link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body style="margin: 5px 5px 5px 5px;">
<?php
$alreadygotadmin = getadminsettings();
if(@$multiemfblockmessage=='') $multiemfblockmessage="I'm sorry. We are experiencing temporary difficulties at the moment. Please try again later.";
function checkemfuserblock(){
	global $blockmultiemf;
	if(@$blockmultiemf=='') $blockmultiemf=20;
	$multiemfblocked=FALSE;
	$theip = @$_SERVER['REMOTE_ADDR'];
	if($theip=='') $theip = 'none';
	if(@$blockmultiemf!=''){
		mysql_query("DELETE FROM multibuyblock WHERE lastaccess<'" . date('Y-m-d H:i:s', time()-(60*60*24)) . "'") or print(mysql_error());
		$sSQL = "SELECT ssdenyid,sstimesaccess FROM multibuyblock WHERE ssdenyip = 'EMF " . trim(escape_string($theip)) . "'";
		$result = mysql_query($sSQL) or print(mysql_error());
		if($rs = mysql_fetch_array($result)){
			mysql_query("UPDATE multibuyblock SET sstimesaccess=sstimesaccess+1,lastaccess='" . date('Y-m-d H:i:s', time()) . "' WHERE ssdenyid=" . $rs['ssdenyid']) or print(mysql_error());
			if($rs['sstimesaccess'] >= $blockmultiemf) $multiemfblocked=TRUE;
		}else{
			mysql_query("INSERT INTO multibuyblock (ssdenyip,lastaccess) VALUES ('EMF " . trim(escape_string($theip)) . "','" . date('Y-m-d H:i:s', time()) . "')") or print(mysql_error());
		}
		mysql_free_result($result);
	}
	if($theip=='none' || ip2long($theip)==FALSE)
		$sSQL = 'SELECT dcid FROM ipblocking LIMIT 0,1';
	else
		$sSQL = 'SELECT dcid FROM ipblocking WHERE (dcip1=' . ip2long($theip) . ' AND dcip2=0) OR (dcip1 <= ' . ip2long($theip) . ' AND ' . ip2long($theip) . ' <= dcip2 AND dcip2 <> 0)';
	$result = mysql_query($sSQL) or print(mysql_error());
	if(mysql_num_rows($result) > 0)
		$multiemfblocked = TRUE;
	return($multiemfblocked);
}
	if(@$_POST['posted']=='1'){
		$success=TRUE;
		$referer = @$_SERVER['HTTP_REFERER'];
		$host = @$_SERVER['HTTP_HOST'];
		if(@$useemailfriend!=TRUE){
			$xxEFThk='<strong><font color="#FF0000">Email friend is not enabled.</font></strong>';
		}elseif(strpos($referer, $host)===FALSE || @$_POST['efcheck']!=@$_SESSION['eftimestampcheck'] || (time()-$_SESSION['eftimestamp']) > (60*60)){
			$xxEFThk='<strong><font color="#FF0000">I\'m sorry but your email could not be sent at this time.</font></strong>';
			ob_end_clean();
			header('HTTP/1.1 401 Unauthorized');
			exit;
		}elseif(checkemfuserblock()){
			$xxEFThk='<strong><font color="#FF0000">' . $multiemfblockmessage . '</font></strong>';
			ob_end_clean();
			header('HTTP/1.1 403 Forbidden');
			exit;
		}else{
			if(@$htmlemails==TRUE) $emlNl = '<br />'; else $emlNl="\n";
			$theprodid = trim(substr(@$_POST['id'],0,50));
			$sSQL="SELECT adminEmail,adminStoreURL FROM admin WHERE adminID=1";
			$result = mysql_query($sSQL) or print(mysql_error());
			$rs = mysql_fetch_array($result);
			$emailAddr = $rs['adminEmail'];
			$adminStoreURL = $rs['adminStoreURL'];
			$friendsemail = str_replace(array("\r","\n"), '', substr(@$_POST['friendsemail'],0,50));
			$yourname = str_replace(array("\r","\n"), '', substr(@$_POST['yourname'],0,50));
			$youremail = str_replace(array("\r","\n"), '', substr(@$_POST['youremail'],0,50));
			if((substr(strtolower($adminStoreURL),0,7) != 'http://') && (substr(strtolower($adminStoreURL),0,8) != 'https://'))
				$adminStoreURL = 'http://' . $adminStoreURL;
			if(substr($adminStoreURL,-1) != '/') $adminStoreURL .= '/';
			mysql_free_result($result);
			$seBody = $xxEFYF1 . $yourname . ' (' . $youremail . ')' . $xxEFYF2;
			if(trim(@$_POST['yourcomments'])!=''){
				$seBody .= $xxEFYF3 . $emlNl;
				$seBody .= str_replace("\r\n",$emlNl,trim(substr(@$_POST['yourcomments'],0,2000))) . $emlNl;
			}else
				$seBody .= '.' . $emlNl;
			$produrl = 'proddetail.php?prod=' . $theprodid;
			if($theprodid!=''){
				$sSQL = "SELECT pName,pStaticPage FROM products WHERE pID='" . escape_string($theprodid) . "'";
				$result = mysql_query($sSQL) or print(mysql_error());
				if(mysql_num_rows($result)>0){
					$rs = mysql_fetch_array($result);
					if($rs['pStaticPage'] != 0) $produrl = cleanforurl($rs['pName']) . '.php';
				}
				mysql_free_result($result);
			}
			if(@$htmlemails==true){
				$storeLink = $adminStoreURL;
				if(trim(@$_POST["id"]) != "") $storeLink .= $produrl;
				$seBody .= $emlNl . '<a href="' . $storeLink . '">' . $storeLink . '</a>';
			}else{
				$seBody .= $emlNl . $adminStoreURL;
				if(trim(@$_POST["id"]) != "") $seBody .= $produrl;
			}
			$seBody .= $emlNl;
			dosendemail($friendsemail, $emailAddr, $youremail, $yourname . $xxEFRec, $seBody);
		}
?>
<br />
  <table class="cobtbl emftbl" border="0" cellspacing="1" cellpadding="3" width="100%" bgcolor="#B1B1B1">
	<tr>
	  <td class="cobhl emfhl" bgcolor="#EBEBEB" colspan="2" align="center" width="100%">&nbsp;</td>
	</tr>
	<tr>
	  <td class="cobll emfll" bgcolor="#FFFFFF"colspan="2" align="center" width="100%"><p>&nbsp;</p>
	  <p><?php print $xxEFThk?></p>
	  <p><?php print $xxClkClo?></p>
	  <p>&nbsp;</p>
	  <input type="button" name="close" value="<?php print $xxClsWin?>" onclick="javascript:self.close()" />
	  <p>&nbsp;</p>
	  </td>
	</tr>
	<tr>
	  <td class="cobhl emfhl" bgcolor="#EBEBEB" colspan="2" align="center" width="100%">&nbsp;</td>
	</tr>
  </table>
<?php
	}else{
		$eftimestamp=time();
		$eftimestampcheck=md5($eftimestamp.'This is a check'.$adminSecret.' A b H k');
		$_SESSION['eftimestamp']=$eftimestamp;
		$_SESSION['eftimestampcheck']=$eftimestampcheck;
?>
<script language="javascript" type="text/javascript">
<!--
function formvalidator(theForm){
  if (theForm.yourname.value == ""){
    alert("<?php print $xxPlsEntr?> \"<?php print $xxEFNam?>\".");
    theForm.yourname.focus();
    return (false);
  }
  if (theForm.youremail.value == ""){
    alert("<?php print $xxPlsEntr?> \"<?php print $xxEFEm?>\".");
    theForm.youremail.focus();
    return (false);
  }
  if (theForm.friendsemail.value == ""){
    alert("<?php print $xxPlsEntr?> \"<?php print $xxEFFEm?>\".");
    theForm.friendsemail.focus();
    return (false);
  }
  return (true);
}
//-->
</script>
<br />
<form method="post" action="emailfriend.php" onsubmit="return formvalidator(this)">
  <input type="hidden" name="posted" value="1" />
  <input type="hidden" name="id" value="<?php print htmlspecialchars(@$_GET['id'])?>" />
  <input type="hidden" name="efcheck" value="<?php print $eftimestampcheck?>" />
  <table class="cobtbl emftbl" border="0" cellspacing="1" cellpadding="3" width="100%" bgcolor="#B1B1B1">
	<tr>
	  <td class="cobhl emfhl" bgcolor="#EBEBEB" colspan="2" align="center" width="100%" height="30"><strong><?php print $xxEmFrnd?></strong></td>
	</tr>
    <tr>
	  <td class="cobll emfll" bgcolor="#FFFFFF" colspan="2" align="center" width="100%">
		<table border="0" cellspacing="1" cellpadding="1" width="100%">
		  <tr>
			<td width="100%"><?php print $xxEFBlr?>
			</td>
		  </tr>
		</table>
	  </td>
	</tr>
	<tr>
	  <td class="cobhl emfhl" bgcolor="#EBEBEB" width="35%" align="right"><font color="#FF0000">*</font><?php print $xxEFNam?>:</td><td class="cobll emfll" bgcolor="#FFFFFF"><input type="text" name="yourname" size="26" /></td>
	</tr>
	<tr>
	  <td class="cobhl emfhl" bgcolor="#EBEBEB" align="right"><font color="#FF0000">*</font><?php print $xxEFEm?>:</td><td class="cobll emfll" bgcolor="#FFFFFF"><input type="text" name="youremail" size="30" /></td>
	</tr>
	<tr>
	  <td class="cobhl emfhl" bgcolor="#EBEBEB" align="right"><font color="#FF0000">*</font><?php print $xxEFFEm?>:</td><td class="cobll emfll" bgcolor="#FFFFFF"><input type="text" name="friendsemail" size="30" /></td>
	</tr>
	<tr>
	  <td class="cobhl emfhl" bgcolor="#EBEBEB" align="right"><font color="#FF0000">*</font><?php print $xxEFCmt?>:</td><td class="cobll emfll" bgcolor="#FFFFFF"><textarea name="yourcomments" cols="30" rows="5"></textarea></td>
	</tr>
	<tr>
	  <td class="cobll emfll" bgcolor="#FFFFFF" colspan="2" align="center" width="100%" height="30">
		<table width="100%" cellspacing="0" cellpadding="0" border="0">
		  <tr>
			<td width="16" height="26" align="right" valign="bottom">&nbsp;&nbsp;&nbsp;&nbsp;</td>
			<td width="100%" align="center"><input type="submit" value="<?php print $xxSend?>" />&nbsp;&nbsp;<input type="button" value="<?php print $xxClsWin?>" onclick="javascript:self.close()" /></td>
			<td width="16" height="26" align="right" valign="bottom"><img src="images/tablebr.gif" alt="" /></td>
		  </tr>
		</table>
	  </td>
	</tr>
  </table>
</form>
<?php
	} ?>
</body>
</html>
