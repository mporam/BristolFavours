<table border="0" cellspacing="0" cellpadding="0" width="100%" align="center">
<tr>
  <td width="100%">
    <table width="100%" border="0" cellspacing="3" cellpadding="3">
	  <tr> 
        <td width="100%" colspan="2" align="center"><?php print $xxThkErr?>
                <a class="ectlink" href="<?php print $xxHomeURL?>"><strong><?php print $xxCntShp?></strong></a><br />
		<img src="images/clearpixel.gif" width="300" height="3" alt="" />
        </td>
	  </tr>
	</table>
  </td>
</tr>
</table>

