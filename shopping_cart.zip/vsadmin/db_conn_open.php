<SCRIPT language="php">

// You host should be able to provide you with these settings if you do not know them already

$db_username = "";  // Your database login username
$db_password = "";  // Your database login password
$db_name = "";      // The name of the database you wish to use
$db_host = "localhost";   // The address of the database. Often this is localhost, but may be for example db.yoursite.com

//////////////////////////////////////////////////
// Please do not edit anything below this line. //
//////////////////////////////////////////////////

$dbh=mysql_connect($db_host, $db_username, $db_password) or die ('You need to set your database connection in vsadmin/db_conn_open.php.</td></tr></table></body></html>');
mysql_select_db($db_name) or die ('You need to set your database connection in vsadmin/db_conn_open.php.</td></tr></table></body></html>');

</SCRIPT>