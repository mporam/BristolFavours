<?php
// For a description of these parameters and their useage, please open the following URL in your browser
// http://www.ecommercetemplates.com/phphelp/ecommplus/parameters.asp
// These are just a few examples of the parameters you can use to control
// your store. There are many, many more explained at the above URL

$sortBy = 1;
$pathtossl = "";
$taxShipping=0;
$pagebarattop=0;
$productcolumns=2;
$useproductbodyformat=1;
$usesearchbodyformat=1;
$usedetailbodyformat=1;
$useemailfriend=TRUE;
$nobuyorcheckout=FALSE;
$noprice=FALSE;
$expireaffiliate=30;
$usecategoryformat=1;
$allproductsimage="";
$showtaxinclusive=FALSE;
$upspickuptype="03";
$overridecurrency=FALSE;
	$orcsymbol=" AU\$";
	$orcemailsymbol=" AU\$";
	$orcdecplaces=2;
	$orcdecimals=".";
	$orcthousands=",";
	$orcpreamount=TRUE;
$encryptmethod="";
$showcategories=TRUE;
$termsandconditions=FALSE;
$nomarkup=TRUE;

// ===================================================================
// Please do not edit anything below this line
// ===================================================================

error_reporting (E_ALL ^ E_NOTICE);

define("maxprodopts",15);
define("helpbaseurl","http://www.ecommercetemplates.com/phphelp/ecommplus/");
?>